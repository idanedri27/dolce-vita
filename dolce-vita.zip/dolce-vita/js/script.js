$(document).ready(function(){

  // getting all the tasks list

  $.ajax('./config/tasks_list.php', {
    type: 'GET',
    success: function (res) {
      const data = JSON.parse(res);
      $("#all_task").html(Object.keys(data).length);
      const date = Date.parse(new Date());
      const limit_days = 518400000;
      for(i in data){
        const tris_date = Date.parse(data[i].date);
        const total = tris_date - date;
        if(data[i].completed == 1){
          $button ="btn-success";
          $text = "complete";
        }else{
          $button ="btn-warning";
          $text = "uncomplete";
        }
        if(total > limit_days){
          var row = $('<tr>'+ 
          '<td>'+data[i].id +'</td>'+ 
          '<td>'+data[i].content + '</td>'+ 
          '<td>'+ data[i].date+'</td>'+
          '<td class="text-center">'+
          '<a href="./edit_task.php?id='+data[i].id+'&task='+data[i].content + '&date='+ data[i].date+'" class="btn-sm btn-secondary text-decoration-none m-1">edit</a>'+
          '<a href="#" class="btn-sm btn-danger text-decoration-none m-1" onclick="delete_task('+data[i].id+')">delete</a>' +
          '<a href="#" id="complete" class="btn-sm '+$button+' text-decoration-none m-1 btn_'+ data[i].id +'" onclick="complete_task('+ data[i].id + ')">'+$text+'</a>'+
          '</td>'+
          '</tr>'); 
        }else{
          var row = $('<tr>'+ 
          '<td>'+data[i].id +'</td>'+ 
          '<td>'+data[i].content + '</td>'+ 
          '<td>'+ data[i].date+'</td>'+
          '<td class="text-center">'+
          '<a href="./edit_task.php?id='+data[i].id+'&task='+data[i].content + '&date='+ data[i].date+'" class="btn-sm btn-secondary text-decoration-none m-1">edit</a>'+
          '<a href="#" class="btn-sm btn-danger text-decoration-none m-1" onclick="trip_coming_soon('+data[i].id+')">delete</a>' +
          '<a href="#" id="complete"  class="btn-sm '+$button+' text-decoration-none m-1 btn_'+ data[i].id +'" onclick="complete_task('+ data[i].id  +  ')">'+$text+'</a>'+
          '</td>'+
          '</tr>'); 
        }
      
        $("#task_row").append(row);
      }

    },
    error: function (jqXhr, textStatus, errorMessage) {
            console.log('Error' + errorMessage);
    }
  });


    // getting all the completed tasks
  
    $.ajax('./config/tasks_completed.php', {
      type: 'GET',
      success: function (res) {
        const data = JSON.parse(res);
        console.log(Object.keys(data).length);
        $("#completed").html(Object.keys(data).length);
      },
      error: function (jqXhr, textStatus, errorMessage) {
              console.log('Error' + errorMessage);
      }
    });





  // getting all the not completed tasks
  
  $.ajax('./config/tasks_not_completed.php', {
    type: 'GET',
    success: function (res) {
      const data = JSON.parse(res);
      console.log(Object.keys(data).length);
      $("#not_completed").html(Object.keys(data).length);
    },
    error: function (jqXhr, textStatus, errorMessage) {
            console.log('Error' + errorMessage);
    }
  });



  


})


// if trip starting sonn cancel delete button

const  trip_coming_soon =  (id) => {
  alert("Sorry you cant delete this trip it will start soon!");
  return;
}






// adding task to list

const add_task = () => {
    const task_details = $("#task_details").val();
    const task_date = $("#task_date").val();

    if(task_details != "" && task_date != ""){

      $.ajax('./config/add_task.php', {
          type: 'POST',
          data: { task_details, task_date},
          dataType: "JSON",
          success: function (data) {
              $(".message").removeClass("alert-danger");
              $(".message").addClass("alert-success");
              $(".message").html(data);
          },
          error: function (jqXhr, textStatus, errorMessage) {
                  console.log('Error' + errorMessage);
          }
      });
    }else{
      $(".message").removeClass("alert-success");
      $(".message").addClass("alert-danger");
      $(".message").html("Please fill all the field!");
    }
}   




// edit task to list

const edit_task = (id) => {
    const new_task_details = $("#edit_task_details").val();
    const new_task_date = $("#edit_task_date").val();

    if(new_task_details != "" && new_task_date != ""){
      
    $.ajax('./config/edit_task.php', {
        type: 'POST',
        data: { id, new_task_details ,new_task_date},
        dataType: "JSON",
        success: function (res) {
          $(".edit_message").removeClass("alert-danger");
          $(".edit_message").addClass("alert-success");
          $(".edit_message").html(res);

        },
        error: function (errorMessage) {
                console.log('Error' + errorMessage);
        }
    });
   } else{
      $(".edit_message").removeClass("alert-success");
      $(".edit_message").addClass("alert-danger");
      $(".edit_message").html("Please fill all the field!");
    }
  }



// delete task to list

const delete_task = (id) => {

  518400
  if(confirm("Are you sure you want delete this task?")){
  $.ajax('./config/delete_task.php', {
      type: 'POST',
      data: { id },
      dataType: "JSON",
      success: function (res) {
       
        $("#message").removeClass("alert-danger");
        $("#message").addClass("alert-success");
        $("#message").html(res);
        setTimeout(function () {
          window.location.href ="index.php";
        }, 2000);
      },
      error: function (errorMessage) {
              console.log('Error' + errorMessage);
      }
  });
 } 
}



// mark task complete to list

const complete_task = (id) => {

  $.ajax('./config/update_task_completed.php', {
      type: 'POST',
      data: { id },
      dataType: "JSON",
      success: function (res) {
          window.location.href ="index.php";
      },
      error: function (err) {
              console.log('Error' + err);
      }
  });
 } 







 const find_date = () => {
  const first_date = $("#first_date").val();
  const second_date = $("#second_date").val();

  // getting all the tasks list

  $.ajax('./config/find_date.php', {
    type: 'POST',
    data: { first_date, second_date},
    dataType: "JSON",
    success: function (res) {
       const data = res;
      const date = Date.parse(new Date());
      const limit_days = 518400000;
      for(i in data){
        const tris_date = Date.parse(data[i].date);
        const total = tris_date - date;
        if(data[i].completed == 1){
          $button ="btn-success";
          $text = "complete";
        }else{
          $button ="btn-warning";
          $text = "uncomplete";
        }
        if(total > limit_days){
          var row = $('<tr>'+ 
          '<td>'+data[i].id +'</td>'+ 
          '<td>'+data[i].content + '</td>'+ 
          '<td>'+ data[i].date+'</td>'+
          '<td class="text-center">'+
          '<a href="./edit_task.php?id='+data[i].id+'&task='+data[i].content + '&date='+ data[i].date+'" class="btn-sm btn-secondary text-decoration-none m-1">edit</a>'+
          '<a href="#" class="btn-sm btn-danger text-decoration-none m-1" onclick="delete_task('+data[i].id+')">delete</a>' +
          '<a href="#" id="complete" class="btn-sm '+$button+' text-decoration-none m-1 btn_'+ data[i].id +'" onclick="complete_task('+ data[i].id + ')">'+$text+'</a>'+
          '</td>'+
          '</tr>'); 
        }else{
          var row = $('<tr>'+ 
          '<td>'+data[i].id +'</td>'+ 
          '<td>'+data[i].content + '</td>'+ 
          '<td>'+ data[i].date+'</td>'+
          '<td class="text-center">'+
          '<a href="./edit_task.php?id='+data[i].id+'&task='+data[i].content + '&date='+ data[i].date+'" class="btn-sm btn-secondary text-decoration-none m-1">edit</a>'+
          '<a href="#" class="btn-sm btn-danger text-decoration-none m-1" onclick="trip_coming_soon('+data[i].id+')">delete</a>' +
          '<a href="#" id="complete"  class="btn-sm '+$button+' text-decoration-none m-1 btn_'+ data[i].id +'" onclick="complete_task('+ data[i].id  +  ')">'+$text+'</a>'+
          '</td>'+
          '</tr>'); 
        }
        $("#task_row").html('');
        $(".find_date").append(row);
      }

    },
    error: function (jqXhr, textStatus, errorMessage) {
            console.log('Error' + errorMessage);
    }
})
 

 }