<?php
require_once "./layout/header.php";

if(isset($_GET['id'])){
    $id = $_GET['id'];
}
?>

<div class="edit_message alert col-md-5 mx-auto text-center"></div>
<div class="container mt-5">
    <div class="row m-0">
        <div class="col-12 text-center">
            <h2>Edit Task number <?= $id ?></h2>
        </div>
    </div>

    <form class="mt-5">
        <div class="mb-3 col-md-6 mx-auto">
            <label for="exampleInputEmail1" class="form-label">Edit Task Details</label>
            <input type="text" class="form-control" id="edit_task_details" value="<?= $_GET['task'] ? $_GET['task'] : '' ?>">
        </div>
        <div class="mb-3 col-md-6 mx-auto">
            <label for="exampleInputPassword1" class="form-label">Edit Date</label>
            <input type="date" class="form-control" id="edit_task_date" value="<?= $_GET['date'] ? $_GET['date'] : '' ?>">
        </div>
        <div class="mb-3 col-md-6 mx-auto w-md-50">
        <a class="btn btn-success w-100" onclick="edit_task(<?= $id ?>)">Edit Task</a>
        </div>
    </form>
</div>

<div class="mb-3 col-md-6 mx-auto w-md-50 text-center mt-5">
    <a href="./index.php" class="btn btn-secondary">Back to lists</a>
</div>
<?php
require_once "./layout/footer.php";
?>
