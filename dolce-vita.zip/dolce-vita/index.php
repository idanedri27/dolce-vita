<?php
require_once dirname(__FILE__) ."/layout/header.php";
?>
<div class="alert col-md-5 mx-auto text-center" id="message"></div>

    <div class="container">
        <div class="row m-0 mt-5">
            <div class="col-md-4">
             <div class="input-group mb-3">
                 <div class="form-control bg-light">Total Tasks</div>
                 <span class="input-group-text bg-dark text-light" id="all_task"></span>
             </div>
            </div>

            <div class="col-md-4">
             <div class="input-group mb-3">
                 <div class="form-control bg-light">Tasks Completed</div>
                 <span class="input-group-text bg-dark text-light" id="completed"></span>
             </div>
            </div>

            <div class="col-md-4">
             <div class="input-group mb-3">
                 <div class="form-control bg-light">Tasks Remaining</div>
                 <spa class="input-group-text bg-dark text-light" id="not_completed"></spa
                 n>
             </div>
            </div>
        </div>
    </div>

    <div class="row m-0 mt-5">
        <div class="col-12 text-center"><a href="./add_task.php" class="btn btn-success">+ Add Task</a></div>
    </div>

    <div class="row m-0 mt-5 d-flex justify-content-center">
    <div class="col-md-2">
    <small>from:</small>
    <input type="date" id="first_date" aria-label="First name" class="form-control"> 
    </div>
    <div class="col-md-2">
    <small>to:</small>
    <input type="date" id="second_date" aria-label="First name" class="form-control">
    </div>
    <div class="col-md-2 mt-4">
    <a href="#" class="btn btn-outline-success" id="find" onclick="find_date()">Search</a>
    </div>
    </div>


    <!-- table -->
 
    <div class="container mt-5">
    <table class="table table-striped">
        <thead class="bg-dark text-light">
            <tr>
            <th scope="col">#</th>
            <th scope="col">Task Details</th>
            <th scope="col">Date</button></th>
            <th scope="col" class="text-center"></th>
            </tr>
        </thead>
        <tbody id="task_row" class="find_date">
           
        </tbody>
    </table>
    </div>
<?php
require_once "./layout/footer.php";
?>