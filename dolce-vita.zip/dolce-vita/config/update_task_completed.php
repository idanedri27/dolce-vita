<?php
require_once dirname(__FILE__)."/db.php";

if(isset($_POST)){
    global $conn;
    $id = intval($_POST['id']);

    $sql_check = "SELECT * FROM tasks  WHERE id = '$id'";
    if ($result = $conn->query($sql_check)) {
        while ($row = $result->fetch_assoc()) {
            if ($row['completed'] == "0") {
                $completed = $row['completed'];
                $sql  = "UPDATE tasks SET completed ='1'  WHERE id = '$id'";
                if ($conn->query($sql)) {
                    echo json_encode("your task completed successfuly!");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }else{
                $completed = $row['completed'];
                $sql  = "UPDATE tasks SET completed ='0'  WHERE id = '$id'";

                if ($conn->query($sql)) {
                    echo json_encode("your task uncompleted successfuly!");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }




}