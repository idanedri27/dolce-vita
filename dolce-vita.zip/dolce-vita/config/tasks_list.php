<?php
require_once dirname(__FILE__)."/db.php";

if(isset($_GET)){

    global $conn;
    $json = [];
    $sql  = "SELECT * FROM tasks";
    $stmt = $conn->prepare($sql);
    $stmt ->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){

       array_push($json , $row);

    }

    echo json_encode($json);
}

