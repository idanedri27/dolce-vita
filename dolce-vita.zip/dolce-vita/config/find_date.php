<?php
require_once dirname(__FILE__)."/db.php";

if(isset($_POST)){
    $first_date =$_POST['first_date'];
    $second_date =$_POST['second_date'];

    global $conn;
    $json = [];
    $sql  = "SELECT * FROM tasks WHERE date BETWEEN '$first_date' AND '$second_date' "; 
    $stmt = $conn->prepare($sql);
    $stmt ->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){

       array_push($json , $row);

    }

    echo json_encode($json);
}

