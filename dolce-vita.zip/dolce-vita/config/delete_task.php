<?php
require_once dirname(__FILE__)."/db.php";

if(isset($_POST['id'])){
    
    $id = intval($_POST['id']);
    global $conn;
    $sql  = "DELETE FROM tasks  WHERE id = '$id'";
    if(mysqli_query($conn, $sql)){
        echo json_encode("your task deleted successfuly!");
    }else{
        echo "Error: " . $sql . "<br>" . $conn->error;
    };
}
