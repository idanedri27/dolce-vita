<?php
require_once dirname(__FILE__)."/db.php";


if(isset($_POST)){
  
   $content = htmlspecialchars($_POST['task_details']);
   $date    = $_POST['task_date'];
   try {
        $sql = "INSERT INTO tasks (content , date) VALUES ('$content' , '$date')";
        if ($conn->query($sql)) {
            echo json_encode("Added to your list successfuly!");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();

   } 
   catch(Exception $e) {
    echo $e->getMessage();
  }
}

