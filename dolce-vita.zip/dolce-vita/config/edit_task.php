<?php
require_once dirname(__FILE__)."/db.php";

if(isset($_GET['id'])){
    $id = intval($_GET['id']);

    global $conn;
    $json=[];
    $sql  = "SELECT * FROM tasks WHERE id = '$id'";
    $stmt = $conn->prepare($sql);
    $stmt ->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){

       array_push($json , $row);

    }
    echo json_encode($json);
}




if(isset($_POST)){

    $id = intval($_POST['id']);
    $new_task_details = $_POST['new_task_details'];
    $new_task_date = $_POST['new_task_date'];

    global $conn;
    $sql  = "UPDATE tasks SET content='$new_task_details' , date = '$new_task_date' WHERE id = '$id'";
    if ($conn->query($sql)) {
        echo json_encode("your task updated successfuly!");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}
